package com.ydemo.base.cores.repository.parameter;

public enum Operator {
    AND,
    OR
}
