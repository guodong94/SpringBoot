package com.ydemo.base.app.model;

import com.ydemo.base.app.entity.Metas;

/**
 * Created by babyant on 17/4/13.
 */
public class MetasDto extends Metas {
    private Integer count;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
